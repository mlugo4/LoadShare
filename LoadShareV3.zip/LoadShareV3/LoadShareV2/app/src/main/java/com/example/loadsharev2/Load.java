package com.example.loadsharev2;

public class Load {
    public String BallisticCoefficient;
    public String BulletName;
    public String BulletType;
    public String BulletWeight;
    public String Caliber;
    public String CaseLength;
    public String LoadName;
    public String OverallLength;
    public String PowderName;
    public String PowderWeight;
    public String PrimerType;

    //public Load(){}

    public Load(String BallisticCoefficient, String BulletName, String BulletType,
                String BulletWeight, String Caliber, String CaseLength, String LoadName,
                String OverallLength, String PowderName, String PowderWeight, String PrimerType){

        this.BallisticCoefficient = BallisticCoefficient;
        this.BulletName = BulletName;
        this.BulletType = BulletType;
        this.BulletWeight = BulletWeight;
        this.Caliber = Caliber;
        this.CaseLength = CaseLength;
        this.LoadName = LoadName;
        this.OverallLength = OverallLength;
        this.PowderName = PowderName;
        this. PowderWeight = PowderWeight;
        this.PrimerType = PrimerType;
    }

}
