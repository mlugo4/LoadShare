package com.example.loadsharev2;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class newLoadActivity extends AppCompatActivity implements ValueEventListener {
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference fbdReference = firebaseDatabase.getReference();
//    private DatabaseReference mBallisticCoefficientRef = fbdReference.child("BallisticCoefficient");
//    private DatabaseReference mBulletNameRef = fbdReference.child("BulletName");
//    private DatabaseReference mBulletTypeRef = fbdReference.child("BulletType");
//    private DatabaseReference mBulletWeightRef = fbdReference.child("BulletWeight");
//    private DatabaseReference mCaliberRef = fbdReference.child("Caliber");
//    private DatabaseReference mCaseLengthRef = fbdReference.child("CaseLength");
//    private DatabaseReference mOverallLengthRef = fbdReference.child("OverallLength");
//    private DatabaseReference mPowderNameRef = fbdReference.child("PowderName");
//    private DatabaseReference mPowderWeightRef = fbdReference.child("PowderWeight");
//    private DatabaseReference mPrimerTypeRef = fbdReference.child("PrimerType");
    //private DatabaseReference mUserRef = fbdReference.child("User");
    private FirebaseAuth mAuth;
    private Button submit;
    private EditText et_Cal, et_BalCo, et_BulNa, et_BulTy, et_BulWt, et_CasLen, et_OvrLen, et_PowNa, et_PowWt, et_PriTy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_load);
        submit = findViewById(R.id.btn_sub);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateLoad();
            }


        });
    }
//        FirebaseUser user = mAuth.getCurrentUser();
//        String username = user.getDisplayName();




    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }
    public void CreateLoad(){
        String BalCo = et_BalCo.getText().toString();
        String BulNa = et_BulNa.getText().toString();
        String BulTy = et_BulTy.getText().toString();
        String BulWt = et_BulWt.getText().toString();
        String Cal = et_Cal.getText().toString();
        String CasLen = et_CasLen.getText().toString();
        String OvrLen = et_OvrLen.getText().toString();
        String PowNa = et_PowNa.getText().toString();
        String PowWt = et_PowWt.getText().toString();
        String PriTy = et_PriTy.getText().toString();
//        FirebaseUser user = mAuth.getCurrentUser();
//        String Username = user.getDisplayName();
//        mBallisticCoefficientRef.setValue(BalCo);
//        mBulletNameRef.setValue(BulNa);
//        mBulletTypeRef.setValue(BulTy);
//        mBulletWeightRef.setValue(BulWt);
//        mCaliberRef.setValue(Cal);
//        mCaseLengthRef.setValue(CasLen);
//        mOverallLengthRef.setValue(OvrLen);
//        mPowderNameRef.setValue(PowNa);
//        mPowderWeightRef.setValue(PowWt);
//        mUserRef.setValue(Username);
        this.
        goHome();

    }

    @Override
    protected void onStart(){
        super.onStart();

//        mBallisticCoefficientRef.addValueEventListener(this);
////        mBulletNameRef.addValueEventListener(this);
////        mBulletTypeRef.addValueEventListener(this);
////        mBulletWeightRef.addValueEventListener(this);
////        mCaliberRef.addValueEventListener(this);
////        mCaseLengthRef.addValueEventListener(this);
////        mOverallLengthRef.addValueEventListener(this);
////        mPowderNameRef.addValueEventListener(this);
////        mPowderWeightRef.addValueEventListener(this);
////        mPrimerTypeRef.addValueEventListener(this);
        //mUserRef.addValueEventListener(this);

    }
    private void goHome(){
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

//eof
}